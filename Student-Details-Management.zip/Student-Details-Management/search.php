<?php

$rollno = $_POST["rollno"];

$host = "localhost";
$dbUsername = "root";
$dbPassword = "";
$dbname = "itlab";

$query = "SELECT * FROM records where rollno =". $rollno;

$conn = new mysqli($host, $dbUsername, $dbPassword, $dbname);

if ( !mysqli_select_db( $conn, $dbname ) ) {
    die( "Could not open database" );
}

$result = mysqli_query( $conn, $query);
if (mysqli_num_rows( $result ) == 0)
{
	die(" No data found");
}
while ($row = mysqli_fetch_row( $result))
{
		echo "<h2>Student's Data</h2><br>NAME: " . $row[0]. "<br>ROLL NUMBER: ". $row[1]. "<br>BRANCH: " . $row[2]. "<br>ADDRESS: ". $row[3] ."<br>";
}
?>