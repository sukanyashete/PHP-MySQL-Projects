<?php

    $rollno = $_POST["rollno"];

    $host = "localhost";
    $dbUsername = "root";
    $dbPassword = "";
    $dbname = "itlab";

    $conn = new mysqli($host, $dbUsername, $dbPassword, $dbname);

    if ( !mysqli_select_db( $conn, $dbname ) ) {
        die( "Could not open database" );
    }

    $query = "DELETE FROM records where rollno =". $rollno; 
    $check = "SELECT * from records Where rollno =". $rollno;
    $stmt = mysqli_query($conn, $check);
    $rnum = $stmt->num_rows;
    if (mysqli_query( $conn, $query)== FALSE){
        echo "Error".$sql."<br>" . mysqli_error($conn);
    }
    else{
        if( $rnum == 0){
            echo "Invalid Roll Number !";
        }
        else 
        {
            echo "Record deleted successfully";
        }
    }

?>