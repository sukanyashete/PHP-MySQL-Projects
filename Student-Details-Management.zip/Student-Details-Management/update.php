<?php

$rollno = $_POST["rollno"];
$change = $_POST["change"];
$new = $_POST["newval"];

$host = "localhost";
$dbUsername = "root";
$dbPassword = "";
$dbname = "itlab";

$conn = new mysqli($host, $dbUsername, $dbPassword, $dbname);

if ( !mysqli_select_db( $conn, $dbname ) ) {
    die( "Could not open database" );
}

$sql = "UPDATE records ". "SET ". $change." = '". $new . "' WHERE rollno = $rollno " ;
$check = "SELECT * from records Where rollno =". $rollno;
$stmt = mysqli_query($conn, $check);
$rnum = $stmt->num_rows;

if (mysqli_query( $conn, $sql)== FALSE){
	echo "Error".$sql."<br>" . mysqli_error($conn);
	}
else{
	if( $rnum == 0){
		echo "Record not found, Updation failed !";
	}
	else 
	{
		echo "<br> record updated successfully";
	}
	}

mysqli_close($conn); 

?>