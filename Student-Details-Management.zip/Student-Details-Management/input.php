<?php

      $name = $_POST['name'];
      $rollno = $_POST['rollno'];
      $branch = $_POST['branch'];
      $address = $_POST['address'];

      $host = "localhost";
	    $dbUsername = "root";
	    $dbPassword = "";
	    $dbname = "itlab";

        $conn = new mysqli($host, $dbUsername, $dbPassword, $dbname);
        if ( !mysqli_select_db( $conn, $dbname ) ) {
            die( "Could not open database" );
        }

      $sql = "INSERT INTO records (name, rollno, branch, address) VALUES('" . $name . "',".$rollno.",'".$branch."','".$address."')";

      if (mysqli_query( $conn, $sql)== TRUE)
      {
        echo "new record created successfully";
      }
      else
      {
        echo "Error".$sql."<br>" . mysqli_error($conn);
      }

      mysqli_close($conn);
?>