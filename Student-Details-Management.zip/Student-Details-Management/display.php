<html>
	<head>
	<title> Display All Records</title>
        <STYLE>
        div{
        font-weight: bold;
        font-size: x-large;
        color:blueviolet; }
        </STYLE>
	</head>

	<body>
	<div>STUDENT DETAILS</div>
	<?php

	$host = "localhost";
	$dbUsername = "root";
	$dbPassword = "";
	$dbname = "itlab";

	$conn = new mysqli($host, $dbUsername, $dbPassword, $dbname);

	if ( !mysqli_select_db( $conn, $dbname ) ) {
		die( "Could not open database" );
	}

				$DISPLAY = "SELECT * from records";
				$result = mysqli_query( $conn, $DISPLAY);
				echo "<table border='1'><th>NAME</th><th>ROLL NUMBER</th><th>BRANCH</th><th>ADDRESS</th>";

				while ($row = mysqli_fetch_row($result)){
					echo "<tr> <td>". $row[0]."</td><td>".$row[1]."</td><td>".$row[2]."</td><td>".$row[3]."</td></tr>";
				}
				echo "</table>";

	mysqli_close($conn); 
	?>
</body>
</html>
