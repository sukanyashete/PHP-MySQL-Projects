<?php

    $empid = $_POST["empid"];

    $host = "localhost";
    $dbUsername = "root";
    $dbPassword = "";
    $dbname = "itlab";

    $conn = new mysqli($host, $dbUsername, $dbPassword, $dbname);

    if ( !mysqli_select_db( $conn, $dbname ) ) {
        die( "Could not open database" );
    }

    $query = "DELETE FROM employee where empid =". $empid; 
    $check = "SELECT * from employee Where empid =". $empid;
    $stmt = mysqli_query($conn, $check);
    $rnum = $stmt->num_rows;
    if (mysqli_query( $conn, $query)== FALSE){
        echo "Error".$sql."<br>" . mysqli_error($conn);
    }
    else{
        if( $rnum == 0){
            echo "Invalid Employee ID !";
        }
        else 
        {
            echo "Record deleted successfully";
        }
    }

?>