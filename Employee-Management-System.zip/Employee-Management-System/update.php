<?php

$empid = $_POST["empid"];
$change = $_POST["change"];
$new = $_POST["newval"];

$host = "localhost";
$dbUsername = "root";
$dbPassword = "";
$dbname = "itlab";

$conn = new mysqli($host, $dbUsername, $dbPassword, $dbname);

if ( !mysqli_select_db( $conn, $dbname ) ) {
    die( "Could not open database" );
}

$sql = "UPDATE employee ". "SET ". $change." = '". $new . "' WHERE empid = $empid " ;
$check = "SELECT * from employee Where empid =". $empid;
$stmt = mysqli_query($conn, $check);
$rnum = $stmt->num_rows;

if (mysqli_query( $conn, $sql)== FALSE){
	echo "Error".$sql."<br>" . mysqli_error($conn);
	}
else{
	if( $rnum == 0){
		echo "Record not found, Updation failed !";
	}
	else 
	{
		echo "<br>Employee Detail updated successfully";
	}
	}

mysqli_close($conn); 

?>