<?php

      $name = $_POST['name'];
      $empid = $_POST['empid'];
      $dept = $_POST['dept'];
      $address = $_POST['address'];

        $host = "localhost";
	    $dbUsername = "root";
	    $dbPassword = "";
	    $dbname = "itlab";

        $conn = new mysqli($host, $dbUsername, $dbPassword, $dbname);
        if ( !mysqli_select_db( $conn, $dbname ) ) {
            die( "Could not open database" );
        }

      $sql = "INSERT INTO employee (name, empid, department, address) VALUES('" . $name . "',".$empid.",'".$dept."','".$address."')";

      if (mysqli_query( $conn, $sql)== TRUE)
      {
        echo "New Employee added successfully";
      }
      else
      {
        echo "Error".$sql."<br>" . mysqli_error($conn);
      }

      mysqli_close($conn);
?>