<html>
	<head>
	<title> Display All Records</title>
        <STYLE>
        div{
        font-weight: bold;
        font-size: x-large;
        color:rebeccapurple; }
        </STYLE>
	</head>

	<body>
	<div>EMPLOYEE DETAILS</div>
	<?php

	$host = "localhost";
	$dbUsername = "root";
	$dbPassword = "";
	$dbname = "itlab";

	$conn = new mysqli($host, $dbUsername, $dbPassword, $dbname);

	if ( !mysqli_select_db( $conn, $dbname ) ) {
		die( "Could not open database" );
	}

				$DISPLAY = "SELECT * from employee";
				$result = mysqli_query( $conn, $DISPLAY);
				echo "<table border='2'><th>NAME</th><th>EMPLOYEE ID</th><th>DEPARTMENT</th><th>ADDRESS</th>";

				while ($row = mysqli_fetch_row($result)){
					echo "<tr> <td>". $row[0]."</td><td>".$row[1]."</td><td>".$row[2]."</td><td>".$row[3]."</td></tr>";
				}
				echo "</table>";

	mysqli_close($conn); 
	?>
</body>
</html>
