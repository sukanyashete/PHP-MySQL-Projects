<?php

$pid = $_POST['pid'];
$table = $_POST['table'];

$host = "localhost";
$dbUsername = "root";
$dbPassword = "";
$dbname = "health";

$conn = new mysqli($host, $dbUsername, $dbPassword, $dbname);
$query = "DELETE FROM ".$table." where pid = '$pid'"; 

if( mysqli_query($conn,$query) == TRUE){
    header('location:option.html');
}
else{
    header('location:delete.html');
} 

mysqli_close($conn);

?>