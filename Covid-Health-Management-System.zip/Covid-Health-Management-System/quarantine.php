<?php

$patientID = $_POST['pid'];
$name = $_POST['pname'];
$dateofjoining = $_POST['doj'];

$host = "localhost";
$dbUsername = "root";
$dbPassword = "";
$dbname = "health";

$conn = new mysqli($host, $dbUsername, $dbPassword, $dbname);
$sql = "INSERT INTO quarantine(pid, name, DOJ) VALUES('$patientID','$name','$dateofjoining')"; 

$check = "Select * from patient where pid = '$patientID'";
$run= mysqli_query($conn,$check);
$num = mysqli_num_rows($run);

if( $num == 0){
    die("Patient id doesnt exist, please recheck and enter again.");
    header('location:quarantine.html');
}
else {
    mysqli_query($conn,$sql);
    header('location:insert.html');
}
    mysqli_close($conn);

?>