<?php

$pid = $_POST['pid'];
$name = $_POST['pname'];
$address = $_POST['address'];
$bloodgroup = $_POST['blood'];
$age = $_POST['age'];
$gender = $_POST['gender'];
$district = $_POST['dist'];
$contact = $_POST['phone'];

$host = "localhost";
$dbUsername = "root";
$dbPassword = "";
$dbname = "health";

$conn = new mysqli($host, $dbUsername, $dbPassword, $dbname);

$sql = "INSERT INTO patient (pid, name, address, bloodgroup, age, gender, district, contact) VALUES('$pid','$name','$address', '$bloodgroup', '$age', '$gender', '$district', '$contact')"; 

if (mysqli_query( $conn, $sql)== TRUE)
    {
      echo "New patient details recorded";
      header('location:insert.html');
    }
    else
    {
      header('location:patient.html');
      echo "Error".$sql."<br>" . mysqli_error($conn);
    }

    mysqli_close($conn);

?>