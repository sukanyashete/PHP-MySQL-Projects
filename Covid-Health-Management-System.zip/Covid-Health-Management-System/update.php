<?php

$pid = $_POST['pid'];
$change = $_POST['change'];
$newval = $_POST['newval'];

$host = "localhost";
$dbUsername = "root";
$dbPassword = "";
$dbname = "health";

$conn = new mysqli($host, $dbUsername, $dbPassword, $dbname);
$query = "Update patient set $change = '$newval' where pid='$pid'"; 

if( mysqli_query($conn,$query) == TRUE){
    header('location:option.html');
}
else{
    header('location:update.html');
} 

mysqli_close($conn);

?>