<?php

session_start();

$username = $_POST['username'] ;
$password = $_POST['password'] ;


$host = "localhost";
$dbUsername = "root";
$dbPassword = "";
$dbname = "health";

$conn = new mysqli($host, $dbUsername, $dbPassword, $dbname);
$query = " select * from credential where username = '$username' && password='$password'";
$result = mysqli_query($conn, $query);
$num = mysqli_num_rows($result);

if( $num == 1){
    header('location:option.html');
}else{
	echo("Invalid username or password !!!");
   header('location:login.html');
}
    mysqli_close($conn);
?>