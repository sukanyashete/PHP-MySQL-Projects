  <html>
    <head>
    <link rel="stylesheet" href="style.css">
  <style>
    body{
      background-image: url("pictures/others.jpg")
    }
    .display{
        text-align: center;
        color: wheat;
    }
    table{
      color: whitesmoke;
    }
  </style>
  <title>health.com</title>
</head>
<body>
<div class="back-btn">
    <a href="option.html">BACK </a>
  </div>
  <div class="logout-btn">
    <a href="login.html">LOG OUT </a>
  </div>
  <br><br><br>
  <div class="heading"> SEARCH RESULT </div><br><BR><BR>
</body>

  </html>
  <?php
        $pid = $_POST['pid'];

        $host = "localhost";
        $dbUsername = "root";
        $dbPassword = "";
        $dbname = "health";

        $conn = new mysqli($host, $dbUsername, $dbPassword, $dbname);
        $select = "Select * from patient where pid= '$pid'";
        $result = mysqli_query( $conn, $select);
        $rnum = $result -> num_rows;
        echo " <div class='display'> ";
        if ($rnum == 0){
           echo "<h2>Patient record not found, please recheck patient ID ! </h2>";
        }
        else{
        echo "<table border='1' align='center'><th>Patient ID</th><th>NAME</th><th>ADDRESS</th><th>BLOOD GROUP</th><th>AGE</th><th>GENDER</th><th>DISTRICT</th><th>CONTACT</th>";
        while ($row = mysqli_fetch_row($result)){
            echo "<tr> <td>". $row[0]."</td><td>".$row[1]."</td><td>".$row[2]."</td><td>".$row[3]."</td><td>".$row[4]."</td><td>".$row[5]."</td><td>".$row[6]."</td><td>".$row[7]."</td></tr>";
        }
        echo "</table><br><B>STATUS : </B>";
        $pos = "Select * from positive where pid = '$pid'";
        $qua = "Select * from quarantine where pid = '$pid'";
        $p = mysqli_query($conn,$pos);
        $q = mysqli_query($conn,$qua);
        if (mysqli_num_rows($p) == TRUE ){
            echo "COVID POSITIVE";
        }else if(mysqli_num_rows($q) == TRUE){
            echo "IN QUARANTINE";
        } else{
            echo "DISCHARGED";
        }
        echo "</div>";
    }
    ?>

 
