<?php

session_start();
header('location:login.html');

$name = $_POST['name'] ;
$email = $_POST['email'] ;
$contact = $_POST['mobile'] ;
$username = $_POST['username'] ;
$password = $_POST['password'] ;
$confpass = $_POST['re-password'] ;

$host = "localhost";
$dbUsername = "root";
$dbPassword = "";
$dbname = "health";

$conn = new mysqli($host, $dbUsername, $dbPassword, $dbname);
$query = " select * from credential where username = '$username'";
$result = mysqli_query($conn, $query);
$num = mysqli_num_rows($result);

if( $num > 0){
    echo "Username already taken !!!";
}else{
    $sql = "INSERT INTO credential (name, email, contact, username, password, confirmpass) VALUES('$name','$email', '$contact', '$username', '$password', '$confpass')"; 
    if (mysqli_query( $conn, $sql)== TRUE)
    {
      echo "New user added successfully";
    }
    else
    {
      echo "Error".$sql."<br>" . mysqli_error($conn);
    }
}

    mysqli_close($conn);
?>